function changeimg1()
{
    const ele =document.getElementById("img")
    newele="https://upload.wikimedia.org/wikipedia/en/8/84/Prison_Break_%28miniseries%29.jpg"
    ele.src =newele
}
function changeimg2()
{
    const ele =document.getElementById("img")
    newele="https://i.ytimg.com/sh/ow8-ZftRoZelY710tvO45Q/market.jpg"
    ele.src =newele
}

function changeimg3()
{
    const ele =document.getElementById("img")
    newele="https://assets.gopaisa.com/unsafe/0x0/https://gpcdn.ams3.cdn.digitaloceanspaces.com/deals/dark-season-3.jpg"
    ele.src =newele
}