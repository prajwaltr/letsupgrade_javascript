function copy()
{
    let ele = document.getElementsByClassName("input")
     ele[1].value=ele[0].value
    //  console.log(ele[1].value)
}