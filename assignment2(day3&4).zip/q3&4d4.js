let details=[]
console.log("Enter the number of details u need to put")
let x=prompt("number of person's detail")
let i=0
for(i=0;i<x;i++)
{
    let detail={
        "name": prompt("Enter name"),
        "age" : prompt("Enter age"),
        "country" : prompt("Enter country"),
        "hobbies": [prompt("Enter H1"),prompt("Enter H2"),prompt("Enter H3")],
    }
    details.push(detail)
}
console.log(details)
//******************************************************************************//
//QUESTION 4
console.log("Showing all the objectswhose age is below 30")
details.map(detail =>
    {
        if (detail.age <30)
        {
           console.log(detail)
        }
    }
    )
    //OR // let indias = details.filter(detail => detail.age<30)
    //  console.log(indias)

console.log("Showing all the objects whose country is INDIA")
        
    let india = details.filter(detail => detail.country=="india")
     console.log(india)

   
    
    

