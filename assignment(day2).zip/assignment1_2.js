let min= prompt();
sec= min*60;
console.log(sec+" seconds")