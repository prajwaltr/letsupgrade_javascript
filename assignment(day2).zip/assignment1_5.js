var ar=[1,2,3,4,5,6,7]
for(let i=ar.length;i>0;i--)
{
    console.log(i)
}