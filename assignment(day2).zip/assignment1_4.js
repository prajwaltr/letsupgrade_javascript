var a=["all","bro","hat","virat"]
for(let i=0;i<4;i++)
{
    for(let n=0;n<a[i].length;n++)
    {
      if(a[i][n]=='a')
      {
          console.log(a[i])
      }
    }
}