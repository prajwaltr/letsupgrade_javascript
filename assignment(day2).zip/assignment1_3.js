var ary = [5,10,15,20,25];
let ele= prompt()
for(let i=0;i<5;i++)
{
    if(ele==ary[i])
    {console.log("found")}  
}

