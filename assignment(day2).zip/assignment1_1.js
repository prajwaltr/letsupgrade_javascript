let s="javascript"
n=s.indexOf(prompt())
console.log(n)